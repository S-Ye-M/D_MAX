import os
import random
import math
import pygame
from os import listdir
from os.path import isfile, join
pygame.init()

pygame.display.set_caption("Platformer")

# Launch in fullscreen using the monitor's actual resolution, so the HUD,
# camera scrolling, and level layout all scale correctly to the real screen.
_display_info = pygame.display.Info()
WIDTH, HEIGHT = _display_info.current_w, _display_info.current_h
FPS = 60
PLAYER_VEL = 5

window = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)

COIN_VALUE = 10
COINS_PER_LEVEL = 20          # total coins that spawn in each level
COINS_REQUIRED_TO_ADVANCE = 15  # how many must be collected to unlock the flag

# Each level gets its own background graphic for visual variety.
LEVEL_BACKGROUNDS = {
    1: "Green.png",
    2: "Yellow.png",
    3: "Purple.png",
    4: "Brown.png",
    5: "Gray.png",
}
TOTAL_LEVELS = 5
STARTING_LIVES = 3


# ---------------------------------------------------------------------------
# Sprite loading helpers
# ---------------------------------------------------------------------------

def flip(sprites):
    return [pygame.transform.flip(sprite, True, False) for sprite in sprites]


def load_sprite_sheets(dir1, dir2, width, height, direction=False):
    path = join("assets", dir1, dir2)
    images = [f for f in listdir(path) if isfile(join(path, f))]

    all_sprites = {}

    for image in images:
        sprite_sheet = pygame.image.load(join(path, image)).convert_alpha()

        sprites = []
        for i in range(sprite_sheet.get_width() // width):
            surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
            rect = pygame.Rect(i * width, 0, width, height)
            surface.blit(sprite_sheet, (0, 0), rect)
            sprites.append(pygame.transform.scale2x(surface))

        if direction:
            all_sprites[image.replace(".png", "") + "_right"] = sprites
            all_sprites[image.replace(".png", "") + "_left"] = flip(sprites)
        else:
            all_sprites[image.replace(".png", "")] = sprites

    return all_sprites


def load_single_sheet(path, width, height, scale2x=True):
    sprite_sheet = pygame.image.load(path).convert_alpha()
    sprites = []
    for i in range(sprite_sheet.get_width() // width):
        surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
        rect = pygame.Rect(i * width, 0, width, height)
        surface.blit(sprite_sheet, (0, 0), rect)
        if scale2x:
            surface = pygame.transform.scale2x(surface)
        sprites.append(surface)
    return sprites


def get_block(size):
    path = join("assets", "Terrain", "Terrain.png")
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((size, size), pygame.SRCALPHA, 32)
    rect = pygame.Rect(96, 0, size, size)
    surface.blit(image, (0, 0), rect)
    return pygame.transform.scale2x(surface)


# ---------------------------------------------------------------------------
# Player
# ---------------------------------------------------------------------------

class Player(pygame.sprite.Sprite):
    COLOR = (255, 0, 0)
    GRAVITY = 1
    SPRITES = load_sprite_sheets("MainCharacters", "MaskDude", 32, 32, True)
    ANIMATION_DELAY = 3

    def __init__(self, x, y, width, height):
        super().__init__()
        self.spawn_x = x
        self.spawn_y = y
        self.rect = pygame.Rect(x, y, width, height)
        self.x_vel = 0
        self.y_vel = 0
        self.mask = None
        self.direction = "left"
        self.animation_count = 0
        self.fall_count = 0
        self.jump_count = 0
        self.hit = False
        self.hit_count = 0
        self.invincible_count = 60
        self.reset_requested = False  # True when level should restart (fell in pit / touched enemy)

    def jump(self):
        self.y_vel = -self.GRAVITY * 8
        self.animation_count = 0
        self.jump_count += 1
        if self.jump_count == 1:
            self.fall_count = 0

    def move(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy

    def make_hit(self):
        if self.invincible_count == 0:
            self.hit = True
            self.reset_requested = True
            self.invincible_count = 1

    def move_left(self, vel):
        self.x_vel = -vel
        if self.direction != "left":
            self.direction = "left"
            self.animation_count = 0

    def move_right(self, vel):
        self.x_vel = vel
        if self.direction != "right":
            self.direction = "right"
            self.animation_count = 0

    def loop(self, fps):
        self.y_vel += min(1, (self.fall_count / fps) * self.GRAVITY)
        self.move(self.x_vel, self.y_vel)

        if self.hit:
            self.hit_count += 1
        if self.hit_count > fps // 2:
            self.hit = False
            self.hit_count = 0

        if self.invincible_count > 0:
            self.invincible_count += 1
            if self.invincible_count > fps * 1.2:
                self.invincible_count = 0

        # fell into a pit
        if self.rect.top > HEIGHT + 200:
            self.reset_requested = True

        self.fall_count += 1
        self.update_sprite()

    def landed(self):
        self.fall_count = 0
        self.y_vel = 0
        self.jump_count = 0

    def hit_head(self):
        self.count = 0
        self.y_vel *= -1

    def update_sprite(self):
        sprite_sheet = "idle"
        if self.hit:
            sprite_sheet = "hit"
        elif self.y_vel < 0:
            if self.jump_count == 1:
                sprite_sheet = "jump"
            elif self.jump_count == 2:
                sprite_sheet = "double_jump"
        elif self.y_vel > self.GRAVITY * 2:
            sprite_sheet = "fall"
        elif self.x_vel != 0:
            sprite_sheet = "run"

        sprite_sheet_name = sprite_sheet + "_" + self.direction
        sprites = self.SPRITES[sprite_sheet_name]
        sprite_index = (self.animation_count //
                        self.ANIMATION_DELAY) % len(sprites)
        self.sprite = sprites[sprite_index]
        self.animation_count += 1
        self.update()

    def update(self):
        self.rect = self.sprite.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.sprite)

    def draw(self, win, offset_x):
        if self.invincible_count == 0 or self.invincible_count % 10 < 5:
            win.blit(self.sprite, (self.rect.x - offset_x, self.rect.y))


# ---------------------------------------------------------------------------
# Generic level objects
# ---------------------------------------------------------------------------

class Object(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, name=None):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.width = width
        self.height = height
        self.name = name

    def loop(self):
        pass

    def draw(self, win, offset_x):
        win.blit(self.image, (self.rect.x - offset_x, self.rect.y))


class Block(Object):
    def __init__(self, x, y, size):
        super().__init__(x, y, size, size)
        block = get_block(size)
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)


class Fire(Object):
    ANIMATION_DELAY = 3

    def __init__(self, x, y, width, height):
        super().__init__(x, y, width, height, "fire")
        self.fire = load_sprite_sheets("Traps", "Fire", width, height)
        self.image = self.fire["off"][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = "off"

    def on(self):
        self.animation_name = "on"

    def off(self):
        self.animation_name = "off"

    def loop(self):
        sprites = self.fire[self.animation_name]
        sprite_index = (self.animation_count //
                        self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1

        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)

        if self.animation_count // self.ANIMATION_DELAY > len(sprites):
            self.animation_count = 0


class Coin(Object):
    ANIMATION_DELAY = 4
    COIN_SPRITES = load_single_sheet(
        join("assets", "Items", "Fruits", "Apple.png"), 32, 32)

    def __init__(self, x, y, size=28):
        super().__init__(x, y, size, size, "coin")
        self.image = self.COIN_SPRITES[0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.collected = False

    def loop(self):
        sprites = self.COIN_SPRITES
        sprite_index = (self.animation_count //
                        self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1

        if self.animation_count // self.ANIMATION_DELAY >= len(sprites):
            self.animation_count = 0

    def draw(self, win, offset_x):
        if not self.collected:
            win.blit(self.image, (self.rect.x - offset_x, self.rect.y))


class Saw(Object):
    ANIMATION_DELAY = 3
    SAW_SPRITES = load_single_sheet(
        join("assets", "Traps", "Saw", "on.png"), 38, 38)

    def __init__(self, x, y, width, height, move_range=150, speed=2, vertical=False):
        super().__init__(x, y, width, height, "saw")
        self.sprites = self.SAW_SPRITES
        self.image = self.sprites[0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.start_x = x
        self.start_y = y
        self.move_range = move_range
        self.speed = speed
        self.vertical = vertical
        self.direction = 1

    def loop(self):
        sprites = self.sprites
        sprite_index = (self.animation_count //
                        self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        if self.animation_count // self.ANIMATION_DELAY >= len(sprites):
            self.animation_count = 0

        if self.vertical:
            self.rect.y += self.speed * self.direction
            if abs(self.rect.y - self.start_y) >= self.move_range:
                self.direction *= -1
        else:
            self.rect.x += self.speed * self.direction
            if abs(self.rect.x - self.start_x) >= self.move_range:
                self.direction *= -1

        self.mask = pygame.mask.from_surface(self.image)


class SpikeBall(Object):
    """A swinging spiked ball on a chain - hangs and swings side to side."""
    BALL_IMG = None

    def __init__(self, x, y, size=28, swing_range=120, speed=0.04):
        super().__init__(x, y, size, size, "spikeball")
        if SpikeBall.BALL_IMG is None:
            img = pygame.image.load(
                join("assets", "Traps", "Spiked Ball", "Spiked Ball.png")).convert_alpha()
            SpikeBall.BALL_IMG = pygame.transform.scale2x(img)
        self.image = self.BALL_IMG
        self.mask = pygame.mask.from_surface(self.image)
        self.anchor_x = x
        self.anchor_y = y
        self.swing_range = swing_range
        self.speed = speed
        self.angle = 0

    def loop(self):
        self.angle += self.speed
        self.rect.x = int(self.anchor_x + math.sin(self.angle) * self.swing_range)
        self.mask = pygame.mask.from_surface(self.image)


class Spikes(Object):
    """Static spikes on the ground - instant hit on touch."""

    def __init__(self, x, y, size=32):
        super().__init__(x, y, size, size, "saw")  # reuse "saw" -> deals damage
        img = pygame.image.load(
            join("assets", "Traps", "Spikes", "Idle.png")).convert_alpha()
        self.image = pygame.transform.scale(img, (size, size))
        self.mask = pygame.mask.from_surface(self.image)


class RockHead(Object):
    """Moves back and forth along a track - faster, more relentless enemy."""
    ROCK_SPRITES = None

    def __init__(self, x, y, size=42, move_range=250, speed=3, vertical=False):
        super().__init__(x, y, size, size, "saw")  # reuse "saw" -> deals damage
        if RockHead.ROCK_SPRITES is None:
            img = pygame.image.load(
                join("assets", "Traps", "Rock Head", "Idle.png")).convert_alpha()
            RockHead.ROCK_SPRITES = pygame.transform.scale2x(img)
        self.image = self.ROCK_SPRITES
        self.mask = pygame.mask.from_surface(self.image)
        self.start_x = x
        self.start_y = y
        self.move_range = move_range
        self.speed = speed
        self.vertical = vertical
        self.direction = 1

    def loop(self):
        if self.vertical:
            self.rect.y += self.speed * self.direction
            if abs(self.rect.y - self.start_y) >= self.move_range:
                self.direction *= -1
        else:
            self.rect.x += self.speed * self.direction
            if abs(self.rect.x - self.start_x) >= self.move_range:
                self.direction *= -1
        self.mask = pygame.mask.from_surface(self.image)


class Flag(Object):
    ANIMATION_DELAY = 6

    def __init__(self, x, y, width, height):
        super().__init__(x, y, width, height, "flag")
        image = pygame.image.load(
            join("assets", "Items", "Checkpoints", "Checkpoint",
                 "Checkpoint (Flag Idle)(64x64).png")).convert_alpha()
        self.frames = []
        frame_w = 64
        for i in range(image.get_width() // frame_w):
            surface = pygame.Surface((frame_w, 64), pygame.SRCALPHA, 32)
            rect = pygame.Rect(i * frame_w, 0, frame_w, 64)
            surface.blit(image, (0, 0), rect)
            self.frames.append(pygame.transform.scale2x(surface))
        self.image = self.frames[0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0

    def loop(self):
        sprite_index = (self.animation_count //
                        self.ANIMATION_DELAY) % len(self.frames)
        self.image = self.frames[sprite_index]
        self.animation_count += 1
        if self.animation_count // self.ANIMATION_DELAY >= len(self.frames):
            self.animation_count = 0
        self.mask = pygame.mask.from_surface(self.image)


class Confetti:
    """Purely decorative particle used on the final win screen."""
    SPRITES = None

    def __init__(self):
        if Confetti.SPRITES is None:
            Confetti.SPRITES = load_single_sheet(
                join("assets", "Other", "Confetti (16x16).png"), 16, 16, scale2x=True)
        self.x = random.randint(0, WIDTH)
        self.y = random.randint(-HEIGHT, 0)
        self.speed = random.uniform(2, 6)
        self.sway = random.uniform(0, math.pi * 2)
        self.frame = random.randint(0, len(self.SPRITES) - 1)

    def update(self):
        self.y += self.speed
        self.sway += 0.1
        self.x += math.sin(self.sway) * 1.5
        if self.y > HEIGHT:
            self.y = random.randint(-100, -20)
            self.x = random.randint(0, WIDTH)

    def draw(self, win):
        win.blit(self.SPRITES[self.frame], (self.x, self.y))


# ---------------------------------------------------------------------------
# Background / drawing helpers
# ---------------------------------------------------------------------------

def get_background(name):
    image = pygame.image.load(join("assets", "Background", name))
    _, _, width, height = image.get_rect()
    tiles = []

    for i in range(WIDTH // width + 1):
        for j in range(HEIGHT // height + 1):
            pos = (i * width, j * height)
            tiles.append(pos)

    return tiles, image


def draw_hud(window, font, lives, score, level_num, level_coins):
    score_text = font.render(f"Score: {score}", True, (255, 255, 255))
    window.blit(score_text, (20, 20))

    level_text = font.render(f"Level: {level_num}/{TOTAL_LEVELS}", True, (255, 255, 255))
    window.blit(level_text, (20, 60))

    if level_coins >= COINS_REQUIRED_TO_ADVANCE:
        coin_color = (120, 255, 120)  # green once enough coins are collected
    else:
        coin_color = (255, 230, 80)
    coin_text = font.render(
        f"Coins: {level_coins}/{COINS_PER_LEVEL}  (need {COINS_REQUIRED_TO_ADVANCE} to advance)",
        True, coin_color)
    window.blit(coin_text, (20, 100))

    for i in range(STARTING_LIVES):
        color = (255, 0, 0) if i < lives else (80, 80, 80)
        pygame.draw.rect(window, color, (WIDTH - 40 - i * 35, 20, 25, 25), border_radius=6)


def draw_center_message(window, big_font, font, title, subtitle, title_color=(255, 255, 255)):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 150))
    window.blit(overlay, (0, 0))

    title_surf = big_font.render(title, True, title_color)
    sub_surf = font.render(subtitle, True, (255, 255, 255))

    window.blit(title_surf, (WIDTH // 2 - title_surf.get_width() // 2, HEIGHT // 2 - 60))
    window.blit(sub_surf, (WIDTH // 2 - sub_surf.get_width() // 2, HEIGHT // 2 + 10))


def draw_win_page(window, big_font, font, confetti_particles, total_score):
    window.fill((30, 30, 60))
    for c in confetti_particles:
        c.update()
        c.draw(window)

    title_surf = big_font.render("YOU ARE THE WINNER!", True, (255, 220, 60))
    sub_surf = font.render(f"Final Score: {total_score}", True, (255, 255, 255))
    sub2_surf = font.render("Press R to Play Again", True, (200, 200, 200))

    window.blit(title_surf, (WIDTH // 2 - title_surf.get_width() // 2, HEIGHT // 2 - 100))
    window.blit(sub_surf, (WIDTH // 2 - sub_surf.get_width() // 2, HEIGHT // 2 - 20))
    window.blit(sub2_surf, (WIDTH // 2 - sub2_surf.get_width() // 2, HEIGHT // 2 + 30))

    pygame.display.update()


def draw(window, background, bg_image, player, objects, offset_x, font,
         lives, score, level_num, level_coins):
    for tile in background:
        window.blit(bg_image, tile)

    for obj in objects:
        obj.draw(window, offset_x)

    player.draw(window, offset_x)

    draw_hud(window, font, lives, score, level_num, level_coins)

    pygame.display.update()


# ---------------------------------------------------------------------------
# Collision handling
# ---------------------------------------------------------------------------

SOLID_NAMES = (None,)  # Block objects have name=None and are the only solid terrain


def is_solid(obj):
    """Only plain terrain Blocks should stop the player's movement.
    Coins, fire, saws, spikes, rock heads, spike balls and the flag are all
    passable - touching them is handled separately (damage / collect / win)."""
    return isinstance(obj, Block)


def handle_vertical_collision(player, objects, dy):
    collided_objects = []
    for obj in objects:
        if is_solid(obj) and pygame.sprite.collide_mask(player, obj):
            if dy > 0:
                player.rect.bottom = obj.rect.top
                player.landed()
            elif dy < 0:
                player.rect.top = obj.rect.bottom
                player.hit_head()

            collided_objects.append(obj)

    return collided_objects


def collide(player, objects, dx):
    player.move(dx, 0)
    player.update()
    collided_object = None
    for obj in objects:
        if is_solid(obj) and pygame.sprite.collide_mask(player, obj):
            collided_object = obj
            break

    player.move(-dx, 0)
    player.update()
    return collided_object


def handle_move(player, objects):
    keys = pygame.key.get_pressed()

    player.x_vel = 0
    collide_left = collide(player, objects, -PLAYER_VEL * 2)
    collide_right = collide(player, objects, PLAYER_VEL * 2)

    if keys[pygame.K_LEFT] and not collide_left:
        player.move_left(PLAYER_VEL)
    if keys[pygame.K_RIGHT] and not collide_right:
        player.move_right(PLAYER_VEL)

    handle_vertical_collision(player, objects, player.y_vel)

    # Damage-dealing hazards: checked separately via direct overlap,
    # since they should never block movement, only hurt on touch.
    for obj in objects:
        if obj.name in ("fire", "saw", "spikeball") and pygame.sprite.collide_mask(player, obj):
            player.make_hit()

    # Coin collection - auto-collect on touch (overlap check only)
    coins_collected_now = 0
    for obj in objects:
        if obj.name == "coin" and not obj.collected:
            if pygame.sprite.collide_mask(player, obj):
                obj.collected = True
                coins_collected_now += 1

    return coins_collected_now


# ---------------------------------------------------------------------------
# Level construction - each level is progressively larger & harder
# ---------------------------------------------------------------------------

def build_level(level_num, block_size):
    """Builds a level. Levels get longer and progressively harder."""
    rng = random.Random(1000 + level_num)  # deterministic layout per level

    level_length = 40 + level_num * 12   # grows each level: 52, 64, 76, 88, 100
    gap_count = 2 + level_num            # more pits each level

    gaps = set()
    while len(gaps) < gap_count:
        g = rng.randint(6, level_length - 6)
        if all(abs(g - existing) > 2 for existing in gaps):
            gaps.add(g)

    floor = [Block(i * block_size, HEIGHT - block_size, block_size)
              for i in range(-3, level_length) if i not in gaps]

    objects = [*floor]

    # Track the top-of-surface height (in "rows above floor") at every column
    # so coins/enemies/flag can be placed exactly on top of solid ground,
    # never inside a block and never floating over a pit.
    # row 0 = the main floor row; higher row number = higher up.
    surface_row = {i: (0 if i not in gaps else None) for i in range(-3, level_length)}

    # Raised platforms scattered through the level
    platform_count = 8 + level_num * 2
    platform_columns = [c for c in range(2, level_length - 3)]
    rng.shuffle(platform_columns)
    for px in platform_columns[:platform_count]:
        prow = rng.choice([2, 3, 4])
        objects.append(Block(px * block_size, HEIGHT - block_size * prow, block_size))
        surface_row[px] = prow

    def top_y(col, extra_lift=0):
        """Pixel Y for placing an item's bottom just above the surface at this column."""
        row = surface_row.get(col)
        if row is None:
            row = 0  # fallback (shouldn't be used for gap columns)
        return HEIGHT - block_size * (row + 1) - extra_lift

    def nearest_solid_column(col):
        """Find the closest column (search outward) that actually has solid ground."""
        if surface_row.get(col) is not None:
            return col
        for offset in range(1, 6):
            for c in (col - offset, col + offset):
                if surface_row.get(c) is not None:
                    return c
        return col

    # --- Enemies: different composition per level, harder each time ---
    if level_num == 1:
        fx = nearest_solid_column(6)
        fire = Fire(block_size * fx, top_y(fx, 32), 16, 32)
        fire.on()
        objects.append(fire)
        sx = nearest_solid_column(14)
        objects.append(Saw(block_size * sx, top_y(sx, 38), 38, 38,
                            move_range=120, speed=2, vertical=False))
        # extra enemies
        fx2 = nearest_solid_column(22)
        fire2 = Fire(block_size * fx2, top_y(fx2, 32), 16, 32)
        fire2.on()
        objects.append(fire2)
        sx2 = nearest_solid_column(30)
        objects.append(Saw(block_size * sx2, top_y(sx2, 38), 38, 38,
                            move_range=120, speed=2, vertical=False))

    elif level_num == 2:
        for fx in [5, 20, 35]:
            fx = nearest_solid_column(fx)
            fire = Fire(block_size * fx, top_y(fx, 32), 16, 32)
            fire.on()
            objects.append(fire)
        for i, sx in enumerate([10, 25, 40]):
            sx = nearest_solid_column(sx)
            objects.append(Saw(block_size * sx, top_y(sx, 38), 38, 38,
                                move_range=140, speed=3, vertical=(i % 2 == 1)))

    elif level_num == 3:
        for fx in [4, 18, 32, 48]:
            fx = nearest_solid_column(fx)
            fire = Fire(block_size * fx, top_y(fx, 32), 16, 32)
            fire.on()
            objects.append(fire)
        for i, sx in enumerate([8, 22, 36, 50]):
            sx = nearest_solid_column(sx)
            objects.append(Saw(block_size * sx, top_y(sx, 38), 38, 38,
                                move_range=160, speed=4, vertical=(i % 2 == 0)))
        for sbx in [15, 44]:
            objects.append(SpikeBall(block_size * sbx, HEIGHT - block_size * 3,
                                      swing_range=130, speed=0.05))
        for spx in [12, 28, 46]:
            spx = nearest_solid_column(spx)
            objects.append(Spikes(block_size * spx, top_y(spx, 32)))

    elif level_num == 4:
        for fx in [4, 16, 30, 44, 58]:
            fx = nearest_solid_column(fx)
            fire = Fire(block_size * fx, top_y(fx, 32), 16, 32)
            fire.on()
            objects.append(fire)
        for i, sx in enumerate([9, 20, 33, 47, 60]):
            sx = nearest_solid_column(sx)
            objects.append(Saw(block_size * sx, top_y(sx, 38), 38, 38,
                                move_range=170, speed=5, vertical=(i % 2 == 0)))
        for sbx in [14, 38, 55]:
            objects.append(SpikeBall(block_size * sbx, HEIGHT - block_size * 3,
                                      swing_range=150, speed=0.06))
        for rx in [24, 50]:
            objects.append(RockHead(block_size * rx, HEIGHT - block_size * 2 - 42,
                                     move_range=250, speed=4, vertical=True))
        for spx in [10, 26, 41, 57]:
            spx = nearest_solid_column(spx)
            objects.append(Spikes(block_size * spx, top_y(spx, 32)))

    else:  # level 5 - hardest, everything combined and faster
        for fx in [4, 14, 26, 38, 50, 62, 74]:
            fx = nearest_solid_column(fx)
            fire = Fire(block_size * fx, top_y(fx, 32), 16, 32)
            fire.on()
            objects.append(fire)
        for i, sx in enumerate([9, 19, 30, 42, 54, 66, 78]):
            sx = nearest_solid_column(sx)
            objects.append(Saw(block_size * sx, top_y(sx, 38), 38, 38,
                                move_range=180, speed=6, vertical=(i % 2 == 0)))
        for sbx in [12, 34, 58, 82]:
            objects.append(SpikeBall(block_size * sbx, HEIGHT - block_size * 3,
                                      swing_range=170, speed=0.07))
        for rx in [22, 46, 70]:
            objects.append(RockHead(block_size * rx, HEIGHT - block_size * 2 - 42,
                                     move_range=280, speed=5, vertical=(rx % 2 == 0)))
        for spx in [8, 24, 40, 56, 72, 86]:
            spx = nearest_solid_column(spx)
            objects.append(Spikes(block_size * spx, top_y(spx, 32)))

    # Coins scattered through the level - always placed just above real
    # solid ground (floor or platform), never inside a block, never over a pit.
    solid_columns = [c for c, row in surface_row.items() if row is not None and 1 <= c <= level_length - 2]
    rng.shuffle(solid_columns)
    coin_columns = (solid_columns * ((COINS_PER_LEVEL // max(len(solid_columns), 1)) + 1))[:COINS_PER_LEVEL]
    for cx in coin_columns:
        cy = top_y(cx, 60)  # float the coin ~60px above the surface
        objects.append(Coin(cx * block_size + 20, cy))

    # Flag / finish line at the far end - placed on guaranteed solid ground
    flag_col = nearest_solid_column(level_length - 2)
    flag = Flag(block_size * flag_col, top_y(flag_col, 128), 64, 64)
    objects.append(flag)

    return objects, level_length


# ---------------------------------------------------------------------------
# Main game
# ---------------------------------------------------------------------------

def main(window):
    clock = pygame.time.Clock()

    font = pygame.font.SysFont("arial", 30, bold=True)
    big_font = pygame.font.SysFont("arial", 60, bold=True)

    block_size = 96

    game_state = {
        "level_num": 1,
        "lives": STARTING_LIVES,
        "total_score": 0,
        "level_coins": 0,
        "phase": "playing",   # playing | game_over | won
    }

    def start_level(level_num):
        objects, level_length = build_level(level_num, block_size)
        player = Player(100, HEIGHT - block_size - 100, 50, 50)
        player.loop(FPS)  # initialize sprite/mask immediately so drawing never crashes
        bg_name = LEVEL_BACKGROUNDS.get(level_num, "Blue.png")
        background, bg_image = get_background(bg_name)
        return player, objects, level_length, background, bg_image

    player, objects, level_length, background, bg_image = start_level(game_state["level_num"])
    game_state["level_coins"] = 0

    offset_x = 0
    scroll_area_width = 200
    confetti_particles = [Confetti() for _ in range(120)]

    run = True
    while run:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                break

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    run = False
                    break
                if game_state["phase"] == "playing":
                    if event.key == pygame.K_SPACE and player.jump_count < 2:
                        player.jump()
                if event.key == pygame.K_r and game_state["phase"] in ("game_over", "won"):
                    game_state["level_num"] = 1
                    game_state["lives"] = STARTING_LIVES
                    game_state["total_score"] = 0
                    game_state["phase"] = "playing"
                    player, objects, level_length, background, bg_image = start_level(1)
                    game_state["level_coins"] = 0
                    offset_x = 0

        if game_state["phase"] == "playing":
            player.loop(FPS)
            coins_now = handle_move(player, objects)
            if coins_now:
                game_state["level_coins"] += coins_now
                game_state["total_score"] += coins_now * COIN_VALUE

            for obj in objects:
                obj.loop()

            # check win (touched flag) - only counts if enough coins collected
            for obj in objects:
                if (obj.name == "flag"
                        and game_state["level_coins"] >= COINS_REQUIRED_TO_ADVANCE
                        and pygame.sprite.collide_mask(player, obj)):
                    if game_state["level_num"] >= TOTAL_LEVELS:
                        game_state["phase"] = "won"
                    else:
                        game_state["level_num"] += 1
                        player, objects, level_length, background, bg_image = start_level(game_state["level_num"])
                        game_state["level_coins"] = 0
                        offset_x = 0
                    break

            # check fell/hit -> lose a life & restart same level
            if player.reset_requested:
                game_state["lives"] -= 1
                if game_state["lives"] <= 0:
                    game_state["phase"] = "game_over"
                else:
                    player, objects, level_length, background, bg_image = start_level(game_state["level_num"])
                    game_state["level_coins"] = 0
                    offset_x = 0

            if game_state["phase"] == "playing":
                if ((player.rect.right - offset_x >= WIDTH - scroll_area_width) and player.x_vel > 0) or (
                        (player.rect.left - offset_x <= scroll_area_width) and player.x_vel < 0):
                    offset_x += player.x_vel

                draw(window, background, bg_image, player, objects, offset_x, font,
                     game_state["lives"], game_state["total_score"],
                     game_state["level_num"], game_state["level_coins"])

        if game_state["phase"] == "game_over":
            draw(window, background, bg_image, player, objects, offset_x, font,
                 game_state["lives"], game_state["total_score"],
                 game_state["level_num"], game_state["level_coins"])
            draw_center_message(window, big_font, font, "GAME OVER",
                                 "Press R to Restart from Level 1", (255, 60, 60))
            pygame.display.update()

        elif game_state["phase"] == "won":
            draw_win_page(window, big_font, font, confetti_particles, game_state["total_score"])

    pygame.quit()
    quit()


if __name__ == "__main__":
    main(window)
